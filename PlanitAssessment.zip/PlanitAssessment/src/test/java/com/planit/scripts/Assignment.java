package com.planit.scripts;

import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.xml.LaunchSuite;
import com.planit.accelerators.ActionEngine;
import com.planit.objectrepository.LoginPage_OR;
import com.planit.pages.BooksPage;
import com.planit.pages.LoginPage;
import com.planit.utilities.ExcelReader;

public class Assignment extends ActionEngine {
	ExcelReader pathTestDataSheet = ExcelReader
			.getInstance(System.getProperty("user.dir") + "//TestData//TestData.xlsx");

	final Map<String, String> tAdminData = pathTestDataSheet.getRowValue("UserData", "Data");
	public String username = tAdminData.get("Username");
	public String password = tAdminData.get("Password");
	public String quantity = tAdminData.get("Quantity");
	public String firstname = tAdminData.get("FirstName");
	public String lastname = tAdminData.get("LastName");
	public String email = tAdminData.get("Email");
	public String country = tAdminData.get("Country");
	public String city = tAdminData.get("City");
	public String address1 = tAdminData.get("Address 1");
	public String postalcode = tAdminData.get("PostalCode");
	public String phonenumber = tAdminData.get("PhoneNumber");

	@Test
	public void demoTest() throws Throwable {

		LoginPage loginpg = new LoginPage();
		BooksPage bookspg = new BooksPage();
		// Launch Url
		loginpg.launchUrl();

		// Login with valid credentials
		loginpg.login(username, password);

		String actualAccountid = getText(LoginPage_OR.txtAccountName);
		// Validating Username after login
		Assert.assertEquals(actualAccountid, username);

		// Adding items to card and validating successful message
		bookspg.addToCartAndValidateMessage();

		// Calculate sub-total based on quantity selected
		bookspg.selectShoppingCartValidateTotalAndCheckout();

		// Enter billing Address
		bookspg.enterBillingAddress(firstname, lastname, email, country, city, address1, postalcode, phonenumber);

		// Enter Shipping Address
		bookspg.enterShippingAddress(firstname, lastname, email, country, city, address1, postalcode, phonenumber);

		// Select Shipping Method
		bookspg.shippingMethod();

		// Select Payment method and validate successful message
		bookspg.choosePaymentMethodAndValidateMessage();

		// Confirm order and validate confirmation message
		bookspg.confirmOrderAndValidateMsg();

		// Logout of application
		loginpg.logout();

	}

}
