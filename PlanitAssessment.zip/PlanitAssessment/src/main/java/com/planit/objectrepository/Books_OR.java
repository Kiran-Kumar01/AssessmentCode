package com.planit.objectrepository;

import org.openqa.selenium.By;

public class Books_OR 
{
	public static By lnkBook=By.xpath("(//div[@class='item-box']//a)[1]");
	public static By txtPrice=By.xpath("//span[@class='price-value-13']");
	public static By txtQuantity=By.xpath("//input[contains(@class,'qty-input')]");
	public static By btnAddToCart=By.xpath("//div[@class='add-to-cart-panel']//input[@value='Add to cart']");
	public static By txtAddToCartMsg=By.xpath("//p[@class='content']");

}
