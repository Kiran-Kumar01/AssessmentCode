package com.planit.objectrepository;

import org.openqa.selenium.By;

public class ShoppingCart_OR {
	public static By lnkShoppingCart = By.xpath("//span[text()='Shopping cart']");
	public static By txtProductUnitPrice = By.xpath("//span[@class='product-unit-price']");
	public static By txtboxProductQuantity = By.xpath("//input[@class='qty-input']");
	public static By txtboxProductTotal = By.xpath("//span[@class='product-subtotal']");
	public static By chkboxTermsofservice = By.xpath("//input[@name='termsofservice']");
	public static By btnCheckout = By.id("checkout");

}
