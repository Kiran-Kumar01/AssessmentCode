package com.planit.objectrepository;

import org.openqa.selenium.By;

public class Checkout_OR {
	public static By ddnbillingAddress = By.xpath("//select[@name='billing_address_id']");
	public static By txtboxBillingaddFname = By.id("BillingNewAddress_FirstName");
	public static By txtboxBillingaddLname = By.id("BillingNewAddress_LastName");
	public static By txtboxBillingaddEmail = By.id("BillingNewAddress_Email");
	public static By txtboxBillingCountry = By.id("BillingNewAddress_CountryId");
	public static By txtboxBillingCity = By.id("BillingNewAddress_City");
	public static By txtboxBillingAdd1 = By.id("BillingNewAddress_Address1");
	public static By txtboxBillingPostalCode = By.id("BillingNewAddress_ZipPostalCode");
	public static By txtboxBillingPhoneNumber = By.id("BillingNewAddress_PhoneNumber");
	public static By btnContinueBillingAddress = By
			.xpath("//div[@id='billing-buttons-container']//input[@value='Continue']");

	public static By ddnShippingAddress = By.xpath("//select[@name='shipping_address_id']");
	public static By txtboxShippingaddFname = By.id("ShippingNewAddress_FirstName");
	public static By txtboxShippingaddLname = By.id("ShippingNewAddress_LastName");
	public static By txtboxShippingaddEmail = By.id("ShippingNewAddress_Email");
	public static By txtboxShippingCountry = By.id("ShippingNewAddress_CountryId");
	public static By txtboxShippingCity = By.id("ShippingNewAddress_City");
	public static By txtboxShippingAdd1 = By.id("ShippingNewAddress_Address1");
	public static By txtboxShippingPostalCode = By.id("ShippingNewAddress_ZipPostalCode");
	public static By txtboxShippingPhoneNumber = By.id("ShippingNewAddress_PhoneNumber");
	public static By btnContinueShippingAddress = By
			.xpath("//div[@id='shipping-buttons-container']//input[@value='Continue']");

	public static By radioBtnShippingMethod = By.xpath("//label[contains(text(),'Next Day Air')]");
	public static By btnContinueShippingMethod = By
			.xpath("//div[@id='shipping-method-buttons-container']//input[@value='Continue']");

	public static By radioBtnPaymentMethod = By.xpath("//input[@value='Payments.CashOnDelivery']");
	public static By btnContinuePaymentMethod = By
			.xpath("//div[@id='payment-method-buttons-container']//input[@value='Continue']");
	public static By txtPaymentMethod = By.xpath("//div[@class='section payment-info']//p");
	public static By btnContinuePaymentInformation = By
			.xpath("//div[@id='payment-info-buttons-container']//input[@value='Continue']");

	public static By btnConfirm = By.xpath("//input[@value='Confirm']");
	public static By txtOrderConfirmationMsg = By.xpath("//div[@class='section order-completed']//strong");

	public static By txtOrderNumber = By.xpath("(//ul[@class='details']//li)[1]");
	public static By btnContineCheckout = By.xpath("//div[@class='page checkout-page']//input[@value='Continue']");

	public static By lnkLogout = By.xpath("//a[text()='Log out']");

}
