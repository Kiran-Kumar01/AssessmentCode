package com.planit.objectrepository;

import org.openqa.selenium.By;

public class HomePage_OR 
{
	public static By lnkBooks=By.xpath("//ul[@class='list']//a[normalize-space(text())='Books']");
	public static By lnkBook=By.xpath("(//div[@class='item-box']//a)[1]");
	public static By txtPrice=By.xpath("//span[@class='price-value-13']");
	public static By txtQuantity=By.xpath("//input[@class='qty-input valid']");
	public static By btnAddToCart=By.xpath("//div[@class='add-to-cart-panel']//input[@value='Add to cart']");
	public static By txtAddToCartMsg=By.xpath("//p[@class='content']");
	public static By lnkShoppingCart=By.xpath("//span[text()='Shopping cart']");
	
	
	
	
	
	
	
	
	
	

}
