package com.planit.objectrepository;

import org.openqa.selenium.By;

public class LoginPage_OR 
{
	public static By lnkLogin = By.xpath("//a[@class='ico-login']");
	public static By txtBoxEmail=By.id("Email");
	public static By txtBoxPassword=By.id("Password");
	public static By btnLogin=By.xpath("//input[@value='Log in']");
	public static By txtAccountName = By.xpath("//div[@class='header-links']//a[@class='account']");
	
	

}
