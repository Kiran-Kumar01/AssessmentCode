package com.planit.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.poifs.filesystem.OfficeXmlFileException;
import org.apache.poi.ss.usermodel.Cell;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelReader 
{
	File file;
	
	public static ExcelReader reader;
	public  List<XSSFSheet> _sheets;
	
	public  ExcelReader(String filePath) throws FileNotFoundException
	{
		file = new File(filePath);
	}

	public static ExcelReader getInstance(String filePath)
	{
		try
		{
			
			reader = new ExcelReader(filePath);
		} catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		return reader;
	}
	
	public Map<String, String> getRowValue(int rownum, String sheetName)
	{

		Map<String, String> rowData = null;
		try
		{
			rowData = getSheetData(rownum, sheetName);
		} catch (OfficeXmlFileException e)
		{
			System.out.println("Reading Xlsx file");
			rowData = getXlsxSheetData(1, rownum, sheetName);
		}

		if (!rowData.isEmpty())
		{
			System.out.println(rowData + "re");
			return rowData;
		}
		else
		{

			throw new NullPointerException(rownum + " : doen't exist in " + sheetName + " sheet");
		}
	}
	public Map<String, String> getRowValue(String tcID, String sheetName) {

		final Map<String, String> rowData = getSheetData(tcID, sheetName);
		if (!rowData.isEmpty()) {
			return rowData;
		} else {
			throw new NullPointerException(tcID + " : doen't exist in " + sheetName + " sheet");
		}
	}
	private Map<String, String> getSheetData(int rownum, String sheetName)
	{
		final List<String> rowData = new ArrayList<String>();
		final Map<String, String> rowVal = new LinkedHashMap<String, String>();
		Object value = null;
		final XSSFSheet sheet = getSheet(sheetName);
		final List<String> coulmnNames = getColumns(sheet);
		final XSSFRow row = sheet.getRow(rownum);
		final int firstCellNum = row.getFirstCellNum();
		final int lastCellNum = row.getLastCellNum();
		for (int j = firstCellNum; j < lastCellNum; j++)
		{
			final XSSFCell cell = row.getCell(j);
			if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK)
			{
				rowData.add("");
			}
			
			else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC)
			{
				final Double val = cell.getNumericCellValue();
				value = val.intValue();// cell.getNumericCellValue();
				rowData.add(value.toString());
			}
			else if (cell.getCellType() == Cell.CELL_TYPE_STRING)
			{
				rowData.add(cell.getStringCellValue());
			}
			else if (cell.getCellType() == Cell.CELL_TYPE_BOOLEAN || cell.getCellType() == Cell.CELL_TYPE_ERROR || cell.getCellType() == Cell.CELL_TYPE_FORMULA)
			{
				throw new RuntimeException(" Cell Type is not supported ");
			}
			rowVal.put(coulmnNames.get(j), rowData.get(j));
		}
		return rowVal;

	}
	private Map<String, String> getSheetData(String tcID, String sheetName) {
		final List<String> rowData = new ArrayList<String>();
		final Map<String, String> rowVal = new HashMap<String, String>();
		Object value = null;
		final XSSFSheet sheet = getSheet(sheetName);
		final List<String> coulmnNames = getColumns(sheet);
		final int totalRows = sheet.getPhysicalNumberOfRows();
		final XSSFRow row = sheet.getRow(0);
		final int firstCellNum = row.getFirstCellNum();
		final int lastCellNum = row.getLastCellNum();
		for (int i = 1; i < totalRows; i++) {
			final XSSFRow rows = sheet.getRow(i);
			System.out.println(rows.getCell(0).getStringCellValue());
			final String testLinkID = rows.getCell(0).getStringCellValue();
			if (tcID.equalsIgnoreCase(testLinkID)) {
				for (int j = firstCellNum; j < lastCellNum; j++) {
					final XSSFCell cell = rows.getCell(j);
					if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
						rowData.add("");
					} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
						final Double val = cell.getNumericCellValue();
						value = val.intValue();// cell.getNumericCellValue();
						rowData.add(value.toString());
					} else if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
						rowData.add(cell.getStringCellValue());
					} else if (cell.getCellType() == Cell.CELL_TYPE_BOOLEAN
							|| cell.getCellType() == Cell.CELL_TYPE_ERROR
							|| cell.getCellType() == Cell.CELL_TYPE_FORMULA) {
						throw new RuntimeException(" Cell Type is not supported ");
					}
					rowVal.put(coulmnNames.get(j), rowData.get(j).trim());

				}
				break;
			}

		}
		return rowVal;

	}
	private XSSFSheet getSheet(String sheetName)
	{
		XSSFWorkbook workbook;
		XSSFSheet sheet = null;
		try
		{
			workbook = new XSSFWorkbook(new FileInputStream(file));
			sheet = workbook.getSheet(sheetName);
			return sheet;
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		return sheet;
	}
	 
	 private List<String> getColumns(XSSFSheet sheet, int headerRow)
		{
			final XSSFRow row = sheet.getRow(headerRow);
			final List<String> columnValues = new ArrayList<String>();
			final int firstCellNum = row.getFirstCellNum();
			final int lastCellNum = row.getLastCellNum();
			for (int i = firstCellNum; i < lastCellNum; i++)
			{
				final XSSFCell cell = row.getCell(i);
				columnValues.add(cell.getStringCellValue());
			}
			return columnValues;
		}
	 
	 private List<String> getColumns(XSSFSheet sheet)
		{
			final XSSFRow row = sheet.getRow(0);
			final List<String> columnValues = new ArrayList<String>();
			final int firstCellNum = row.getFirstCellNum();
			final int lastCellNum = row.getLastCellNum();
			for (int i = firstCellNum; i < lastCellNum; i++)
			{
				final XSSFCell cell = row.getCell(i);
				columnValues.add(cell.getStringCellValue());
			}
			return columnValues;
		}
	 private Map<String, String> getXlsxSheetData(int headerRow, int rownum, String sheetName)
		{
			final List<String> rowData = new ArrayList<String>();
			final Map<String, String> rowVal = new LinkedHashMap<String, String>();
			Object value = null;
			final XSSFSheet sheet = getXlsxSheet(sheetName);
			final List<String> coulmnNames = getColumns(sheet, headerRow);
			final XSSFRow row = sheet.getRow(rownum);
			final int firstCellNum = row.getFirstCellNum();
			final int lastCellNum = row.getLastCellNum();
			for (int j = firstCellNum; j < lastCellNum; j++)
			{
				final XSSFCell cell = row.getCell(j);
				if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK)
				{
					rowData.add("");
				}
				else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC)
				{
					final Double val = cell.getNumericCellValue();
					value = val.intValue();// cell.getNumericCellValue();
					rowData.add(value.toString());
				}
				else if (cell.getCellType() == Cell.CELL_TYPE_STRING)
				{
					rowData.add(cell.getStringCellValue());
				}
				else if (cell.getCellType() == Cell.CELL_TYPE_BOOLEAN || cell.getCellType() == Cell.CELL_TYPE_ERROR || cell.getCellType() == Cell.CELL_TYPE_FORMULA)
				{
					throw new RuntimeException(" Cell Type is not supported ");
				}
				rowVal.put(coulmnNames.get(j), rowData.get(j));
			}
			return rowVal;

		}
	 public XSSFSheet getXlsxSheet(String sheetName)
		{
			XSSFWorkbook workbook;
			XSSFSheet sheet = null;
			try
			{
				workbook = new XSSFWorkbook(new FileInputStream(file));
				sheet = workbook.getSheet(sheetName);
				// logger.info(" Data will be read from the sheet :" + sheetName);
				return sheet;
			} catch (IOException e)
			{
				e.printStackTrace();
			}
			return sheet;
		}

}
