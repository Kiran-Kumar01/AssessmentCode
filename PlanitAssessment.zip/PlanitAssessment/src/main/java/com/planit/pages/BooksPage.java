package com.planit.pages;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.planit.objectrepository.Books_OR;
import com.planit.objectrepository.Checkout_OR;
import com.planit.objectrepository.HomePage_OR;
import com.planit.objectrepository.ShoppingCart_OR;

public class BooksPage extends BasePage {
	public void addToCartAndValidateMessage() throws Throwable {
		String price;
		String addToCartMsg;
		JSClick(HomePage_OR.lnkBooks);
		JSClick(Books_OR.lnkBook);
		price = getText(Books_OR.txtPrice);
		System.out.println(price);
		type(Books_OR.txtQuantity, "2");
		JSClick(Books_OR.btnAddToCart);
		waitForVisibilityOfElement(Books_OR.txtAddToCartMsg, 30);
		Thread.sleep(2000);
		addToCartMsg = getText(Books_OR.txtAddToCartMsg);
		System.out.print(addToCartMsg);
		Assert.assertEquals("The product has been added to your shopping cart", addToCartMsg);

	}

	public void selectShoppingCartValidateTotalAndCheckout() throws Throwable {
		String price;
		String quantity;
		JSClick(ShoppingCart_OR.lnkShoppingCart);
		Thread.sleep(3000);
		price = getText(ShoppingCart_OR.txtProductUnitPrice);
		quantity = getValue(ShoppingCart_OR.txtboxProductQuantity);
		float expSubTotal = Float.valueOf(price) * Float.valueOf(quantity);
		String actTotal = getText(ShoppingCart_OR.txtboxProductTotal);
		float actSubTotal = Float.valueOf(actTotal);
		Assert.assertEquals(actSubTotal, expSubTotal);
		JSClick(ShoppingCart_OR.chkboxTermsofservice);
		JSClick(ShoppingCart_OR.btnCheckout);
	}

	public void enterBillingAddress(String firstname, String lastname, String email, String country, String city,
			String address1, String postalcode, String phonenumber) throws Throwable {
		selectByVisibleText(Checkout_OR.ddnbillingAddress, "New Address");
		type(Checkout_OR.txtboxBillingaddFname, firstname);
		type(Checkout_OR.txtboxBillingaddLname, lastname);
		type(Checkout_OR.txtboxBillingaddEmail, email);
		selectByVisibleText(Checkout_OR.txtboxBillingCountry, country);
		type(Checkout_OR.txtboxBillingCity, city);
		type(Checkout_OR.txtboxBillingAdd1, address1);
		type(Checkout_OR.txtboxBillingPostalCode, postalcode);
		type(Checkout_OR.txtboxBillingPhoneNumber, phonenumber);
		JSClick(Checkout_OR.btnContinueBillingAddress);

	}

	public void enterShippingAddress(String firstname, String lastname, String email, String country, String city,
			String address1, String postalcode, String phonenumber) throws Throwable {
		waitForVisibilityOfElement(Checkout_OR.ddnShippingAddress, 20);
		selectByVisibleText(Checkout_OR.ddnShippingAddress, "New Address");
		waitForVisibilityOfElement(Checkout_OR.txtboxShippingaddFname, 20);
		type(Checkout_OR.txtboxShippingaddFname, firstname);
		type(Checkout_OR.txtboxShippingaddLname, lastname);
		type(Checkout_OR.txtboxShippingaddEmail, email);
		selectByVisibleText(Checkout_OR.txtboxShippingCountry, country);
		type(Checkout_OR.txtboxShippingCity, city);
		type(Checkout_OR.txtboxShippingAdd1, address1);
		type(Checkout_OR.txtboxShippingPostalCode, postalcode);
		type(Checkout_OR.txtboxShippingPhoneNumber, phonenumber);
		JSClick(Checkout_OR.btnContinueShippingAddress);
	}

	public void shippingMethod() throws Throwable {
		waitForVisibilityOfElement(Checkout_OR.radioBtnShippingMethod, 20);
		JSClick(Checkout_OR.radioBtnShippingMethod);
		JSClick(Checkout_OR.btnContinueShippingMethod);

	}

	public void choosePaymentMethodAndValidateMessage() throws Throwable {
		String actpaymentmessage;
		String exppaymentmessage = "You will pay by COD";
		waitForVisibilityOfElement(Checkout_OR.radioBtnPaymentMethod, 60);
		JSClick(Checkout_OR.radioBtnPaymentMethod);
		JSClick(Checkout_OR.btnContinuePaymentMethod);
		waitForVisibilityOfElement(Checkout_OR.txtPaymentMethod, 20);
		actpaymentmessage = getText(Checkout_OR.txtPaymentMethod);

		Assert.assertEquals(actpaymentmessage, exppaymentmessage);
		JSClick(Checkout_OR.btnContinuePaymentInformation);

	}

	public void confirmOrderAndValidateMsg() throws Throwable {
		String actualOrderConfirmationMsg;
		String expectedOrderConfirmationMsg = "Your order has been successfully processed!";
		String[] orderNumber;
		waitForVisibilityOfElement(Checkout_OR.btnConfirm, 30);
		JSClick(Checkout_OR.btnConfirm);
		waitForVisibilityOfElement(Checkout_OR.txtOrderConfirmationMsg, 30);
		actualOrderConfirmationMsg = getText(Checkout_OR.txtOrderConfirmationMsg);
		Assert.assertEquals(actualOrderConfirmationMsg, expectedOrderConfirmationMsg);
		orderNumber = getText(Checkout_OR.txtOrderNumber).split(":");
		System.out.println("Order Number is:" + orderNumber[1]);
		JSClick(Checkout_OR.btnContineCheckout);

	}

}
