package com.planit.pages;

import com.planit.objectrepository.HomePage_OR;

public class HomePage extends BasePage
{
	public void addToCartAndValidateMessage() throws Throwable
	{
		JSClick(HomePage_OR.lnkBooks);
		JSClick(HomePage_OR.lnkBook);
		
		
	}
	//addToCartAndValidateMessage
	//checkout
	//EnterAddress
	//BillingAddress
	//ShippingAddress
	//paymentmethod
	//confirmandverifyorder

}
