package com.planit.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import com.planit.accelerators.ActionEngine;
import com.planit.objectrepository.Checkout_OR;

public class BasePage extends ActionEngine {

	
	public void launchUrl() {
		String configReporterFile = "resources/properties";
		String url = read(configReporterFile, "URL");
		System.out.print(url);
		driver.get(url);
		driver.manage().window().maximize();

	}

	public void logout() throws Throwable {
		JSClick(Checkout_OR.lnkLogout);
	}

	public static String read(String fileName, String key) {
		String keyValue = null;

		BufferedReader bufferedReader = null;
		Properties prop = null;

		try {

			bufferedReader = new BufferedReader(new FileReader(fileName));
			prop = new Properties();
			prop.load(bufferedReader);
			keyValue = prop.getProperty(key);
		} catch (Exception e) {

		} finally {

			try {
				bufferedReader.close();

			} catch (IOException e) {

			} catch (NullPointerException e) {

			}
		}

		return keyValue;
	}

}
