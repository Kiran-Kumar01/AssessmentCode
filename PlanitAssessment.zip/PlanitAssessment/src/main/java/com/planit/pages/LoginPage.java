package com.planit.pages;

import com.planit.objectrepository.LoginPage_OR;

public class LoginPage extends BasePage
{
	public void login(String username,String password)
	{
		
			try {
				waitForVisibilityOfElement(LoginPage_OR.lnkLogin, 20);
				JSClick(LoginPage_OR.lnkLogin);
				type(LoginPage_OR.txtBoxEmail, username);
				type(LoginPage_OR.txtBoxPassword, password);
				JSClick(LoginPage_OR.btnLogin);
				
			} catch (Throwable e) {
				
				e.printStackTrace();
			}	
		
		
		
		
	}

}
