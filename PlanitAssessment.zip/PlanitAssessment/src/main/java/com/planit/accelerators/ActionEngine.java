package com.planit.accelerators;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ActionEngine extends TestEngineWeb {

	public boolean waitForVisibilityOfElement(By locator, long timeOutInSeconds) {
		try {

			WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean type(By locator, String testdata) throws Throwable {
		boolean status = false;
		try {

			WebDriverWait wait = new WebDriverWait(driver, 30);
			scrollToElement(locator);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			driver.findElement(locator).clear();
			driver.findElement(locator).sendKeys(testdata);
			status = true;
		} catch (Exception e) {
			status = false;
			e.printStackTrace();
			throw e;
		}
		return status;
	}

	public void scrollToElement(By by) throws Throwable {
		try {
			WebElement element = driver.findElement(by);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

		} catch (Throwable e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean JSClick(By locator) throws Throwable {

		boolean flag = false;

		try {

			WebDriverWait wait = new WebDriverWait(driver, 30);
			scrollToElement(locator);
			// ScrollToElementVisible(locator);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			WebElement element = driver.findElement(locator);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", element);
			flag = true;

		} catch (Throwable e) {
			flag = false;

			throw e;
		}
		return flag;
	}

	public String getText(By locator) throws Throwable {
		String text = "";
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			scrollToElement(locator);
			wait.until(ExpectedConditions.presenceOfElementLocated(locator));
			if (isElementPresent(locator, true)) {
				text = driver.findElement(locator).getText();
				flag = true;
			}

		} catch (Exception e) {

			throw e;
		}
		return text;
	}

	public boolean isElementPresent(By by, boolean expected) throws Throwable {
		boolean status = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			scrollToElement(by);
			wait.until(ExpectedConditions.elementToBeClickable(by));
			driver.findElement(by);

			status = true;
		} catch (Exception e) {
			status = false;
		}
		return status;
	}

	public String getValue(By locator) throws Throwable {
		String text = "";
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			scrollToElement(locator);
			wait.until(ExpectedConditions.presenceOfElementLocated(locator));
			if (isElementPresent(locator, true)) {
				text = driver.findElement(locator).getAttribute("value");
				flag = true;
			}

		} catch (Exception e) {

			throw e;
		}
		return text;
	}

	public boolean selectByVisibleText(By locator, String value) throws Throwable {

		boolean flag = false;
		try {

			WebElement dropDownListBox = driver.findElement(locator);
			Select clickThis = new Select(dropDownListBox);
			clickThis.selectByVisibleText(value);
			flag = true;
			return true;
		} catch (Exception e) {

			return false;

		}

	}
}